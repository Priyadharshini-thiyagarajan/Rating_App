from sqlalchemy import Column, Integer, String, ForeignKey, Float
from sqlalchemy.orm import relationship
from backend.database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(60))
    email = Column(String(100), unique=True)
    password = Column(String(200))
    address = Column(String(400))
    role = Column(String(20))   # admin, user, owner

    ratings = relationship("Rating", back_populates="user")


class Store(Base):
    __tablename__ = "stores"
    id = Column(Integer, primary_key=True)
    name = Column(String(60))
    email = Column(String(100))
    address = Column(String(400))

    ratings = relationship("Rating", back_populates="store")


class Rating(Base):
    __tablename__ = "ratings"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    store_id = Column(Integer, ForeignKey("stores.id"))
    rating = Column(Integer)

    user = relationship("User", back_populates="ratings")
    store = relationship("Store", back_populates="ratings")
