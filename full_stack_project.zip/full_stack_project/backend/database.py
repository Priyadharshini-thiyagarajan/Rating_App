from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = "mysql+pymysql://root:Priyarajan09@localhost/rating_app"
#DATABASE_URL  = "mysql+pymysql://root:Priyarajan%4009@localhost/rating_app"


engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
