from pydantic import BaseModel

class UserCreate(BaseModel):
    name: str
    email: str
    password: str
    address: str
    role: str

class Login(BaseModel):
    email: str
    password: str

class StoreCreate(BaseModel):
    name: str
    email: str
    address: str

class RatingCreate(BaseModel):
    user_id: int
    store_id: int
    rating: int
