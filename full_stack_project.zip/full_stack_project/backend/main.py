from fastapi import FastAPI
from routers import auth, admin, store, ratings

app = FastAPI()

app.include_router(auth.router)
app.include_router(admin.router)
app.include_router(store.router)
app.include_router(ratings.router)

@app.get("/")
def home():
    return {"message": "Backend Running"}
