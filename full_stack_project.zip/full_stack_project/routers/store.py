from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models import Store, Rating

router = APIRouter(prefix="/stores")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/")
def all_stores(db: Session = Depends(get_db)):
    stores = db.query(Store).all()
    output = []
    for s in stores:
        ratings = [r.rating for r in s.ratings]
        avg = sum(ratings) / len(ratings) if ratings else 0
        output.append({
            "id": s.id,
            "name": s.name,
            "address": s.address,
            "rating": avg
        })
    return output
