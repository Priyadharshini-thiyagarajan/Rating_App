from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models import Rating
from backend.schemas import RatingCreate

router = APIRouter(prefix="/rating")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/submit")
def submit(data: RatingCreate, db: Session = Depends(get_db)):
    rating = db.query(Rating).filter(
        Rating.user_id == data.user_id,
        
        Rating.store_id == data.store_id
    ).first()

    if rating:
        rating.rating = data.rating
    else:
        rating = Rating(**data.dict())
        db.add(rating)

    db.commit()
    return {"message": "Rating Submitted"}
