from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from jose import jwt
from backend.database import SessionLocal
from backend.models import User
from backend.schemas import UserCreate, Login

router = APIRouter(prefix="/auth")

SECRET = "SECRET_KEY"
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/signup")
def signup(data: UserCreate, db: Session = Depends(get_db)):
    # hashed = pwd.hash(data.password)
    new_user = User(
        name=data.name,
        email=data.email,
        password=data.password,
        address=data.address,
        role="user"
    )
    db.add(new_user)
    db.commit()
    return {"message": "User Registered"}

@router.post("/login")
def login(data: Login, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()

    if not user:
        raise HTTPException(400, "Invalid Credentials")
    
    return {
        "message": "Login Successful",
        "role": user.role,
        "user_id": user.id
    }

