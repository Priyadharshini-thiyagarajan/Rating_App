from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models import User, Store
from backend.schemas import UserCreate, StoreCreate

router = APIRouter(prefix="/admin")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/add-user")
def add_user(data: UserCreate, db: Session = Depends(get_db)):
    user = User(
        name=data.name,
        email=data.email,
        password=data.password,
        address=data.address,
        role=data.role
    )
    db.add(user)
    db.commit()
    return {"message": "User added"}

@router.post("/add-store")
def add_store(data: StoreCreate, db: Session = Depends(get_db)):
    store = Store(**data.dict())
    db.add(store)
    db.commit()
    return {"message": "Store Added"}

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    return {
        "total_users": db.query(User).count(),
        "total_stores": db.query(Store).count(),
    }
