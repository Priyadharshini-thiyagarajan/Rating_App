import streamlit as st
import requests

BASE = "http://127.0.0.1:8000"

st.title("Store Rating System")

menu = ["Login", "Signup", "Stores"]
choice = st.sidebar.selectbox("Menu", menu)

# ---------------- SIGNUP ---------------------
if choice == "Signup":
    st.header("Create Account")

    name = st.text_input("Name")
    email = st.text_input("Email")
    address = st.text_input("Address")
    print(f"{address=}")
    password = st.text_input("Password", type="password")
    print(f"{password=}")

    if st.button("Register"):
        data = {
            "name": name,
            "email": email,
            "password": password,
            "address": address,
            "role": "user"
        }
        r = requests.post(BASE + "/auth/signup", json=data)
        if r.status_code == 200:
            st.success("Successfully Registered")
        else:
            st.error("Error: " + r.text)

# ---------------- LOGIN ---------------------
elif choice == "Login":
    st.header("User Login")

    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        data = {"email": email, "password": password}

        r = requests.post(BASE + "/auth/login", json=data)

        try:
            if r.status_code == 200:
                response = r.json()       # <-- Important
                st.session_state["id"] = response.get("user_id")
                st.session_state["logged_in"] = True
                st.success("Logged In Successfully")
            else:
                st.error("Error: " + r.text)

        except Exception as e:
            st.error("Backend did not return proper JSON.")
            st.write("Error:", e)
            st.stop()


# ---------------- STORE LIST ---------------------
elif choice == "Stores":

    if "logged_in" not in st.session_state or st.session_state["logged_in"] is False:
        st.error("Please login first to rate stores. Navigate to login page")
        st.stop()

    st.header("All Stores")

    stores = requests.get(BASE + "/stores/").json()

    for s in stores:
        st.subheader(s["name"])
        st.write("Address:", s["address"])
        st.write("Rating:", s["rating"])

        rating = st.slider(f"Rate {s['name']}", 1, 5)

        if st.button(f"Submit"):
            data = {
                "user_id": st.session_state["id"],
                "store_id": s["id"],
                "rating": rating
            }
            requests.post(BASE + "/rating/submit", json=data)
            st.success("Rating Updated")
